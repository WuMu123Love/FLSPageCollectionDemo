//
//  FLSHeader.h
//  FLSPageCollectionDemo
//
//  Created by 天立泰 on 2018/10/24.
//  Copyright © 2018年 天立泰. All rights reserved.
//

#ifndef FLSHeader_h
#define FLSHeader_h

#import "Macro.h"
#import "UIView+Extension.h"
#define WEAKSELF typeof(self) __weak weakSelf = self;

#endif /* FLSHeader_h */
